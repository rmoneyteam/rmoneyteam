# R Money Team Web
Web app para publicar análisis de trading.
